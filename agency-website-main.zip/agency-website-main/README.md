# Agency Website


## designing a new agengy project - Demo agency (one page)

full responsive link: ( https://mkhaque1.github.io/agency-website/)

## Getting Started

### Dependencies

* All screen supported
* Tab/mobile friendly

## Help

Any advise for common problems or issues.
```
command to run if program contains helper info
```

## Authors

Contributors names and contact info

ex. M M Khairul Haque 
ex. (https://www.linkedin.com/in/mkhaque/)

## Version History

* 0.2
    * Various bug fixes and optimizations
    * See [commit change]() or See [release history]()
* 0.1
    * Initial Release

## License

This project is licensed under the [M M Khairul Haque] License - see the LICENSE.md file for details

## Acknowledgments

credits:
*AOS Library
* TILT.js 
* font-awesome
* google-fonts


